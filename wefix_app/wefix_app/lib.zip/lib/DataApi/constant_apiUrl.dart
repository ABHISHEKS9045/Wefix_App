const baseUrl = 'http://134.209.229.112:7071';
const pdfBaseurl = 'http://134.209.229.112/';
const OrdersentUrl = "http://134.209.229.112:7071/owner/add_order";
const AllproductUrl = 'http://134.209.229.112:7071/owner/get_all_product';
const productDetailUrl = 'http://134.209.229.112:7071/owner/click_product?id=';
const searchproductUrl = 'http://134.209.229.112:7071/owner/search_product?search=';
const historyURL = 'http://134.209.229.112:7071/owner/History_list';
const vendorHistoryURL = 'http://134.209.229.112:7071/owner/vendor_owner_History_list';
const editProfileUrl = 'http://134.209.229.112:7071/owner/Edit_profile_details';
const getProfileUrl = 'http://134.209.229.112:7071/owner/Get_owner_details?id=';
const notificationUrl = 'http://134.209.229.112:7071/owner/get_all_notifications?owner_id=';
const vendorNotificationUrl = 'http://134.209.229.112:7071/owner/vendor_all_notifications?vendor_id=';
const searchNotificationUrl = 'http://134.209.229.112:7071/owner/search_notifications?owner_id=';
const searchVendorNotificationUrl = 'http://134.209.229.112:7071/owner/search_vendor_notifications?vendor_id=';
const proposalCountUrl = 'http://134.209.229.112:7071/owner/count_order_status/';
const DMproposalCountUrl = 'http://134.209.229.112:7071/owner/Count_Manager_OrderStatus?order_status=';
const DMproposalPCountUrl = 'http://134.209.229.112:7071/owner/Count_Manager_OrderStatus?order_status=';
const proposal1CountUrl = 'http://134.209.229.112:7071/owner/count_order_status/';
const photogUrl =
    'https://mactosys.com/Report/public/images/products/20221229174830715.jpg';

const acceptOrderAPI = "http://134.209.229.112:7071/owner/order_accept";

const vendorSearchProposalUrl =
    "http://134.209.229.112:7071/owner/search_vendor_Proposal?";
const ownerSearchProposalUrl =
    "http://134.209.229.112:7071/owner/search_Proposal?";

const vendorSearchProposalHistoryUrl =
    "http://134.209.229.112:7071/owner/proposal_history?";
const ownerSearchProposalHistoryUrl =
    "http://134.209.229.112:7071/owner/search_owner_proposal_history?";

const rejectOrderAPI =
    "http://134.209.229.112:7071/owner/order_reject?order_id=";
const ProposalConfirmUrl =
    "http://134.209.229.112:7071/owner/get_Proposal?order_status=confirmed &owner_id=";
const DManegerConfirmUrl =
    "http://134.209.229.112:7071/owner/get_pending_Proposal?order_status=confirmed";
const DManegerPendingUrl =
    "http://134.209.229.112:7071/owner/get_pending_Proposal?order_status=pending";

const ProposalPendingUrl =
    "http://134.209.229.112:7071/owner/get_Proposal?order_status=pending &owner_id=";

const ProposalHistoryUrl =
    "http://134.209.229.112:7071/owner/owner_history?owner_id=";
const DMProposalHistoryUrl = "http://134.209.229.112:7071/owner/get_history_proposal";
const VendorProposalHistoryUrl = "http://134.209.229.112:7071/owner/vendor_history?vendor_id=";

const VendorProposalConfirmUrl = "http://134.209.229.112:7071/owner/get_vendor_Proposal?order_status=confirmed &vendor_id=";
const VendorProposalPendingUrl = "http://134.209.229.112:7071/owner/get_vendor_Proposal?order_status=pending &vendor_id=";


const Productlist = "http://206.189.13.31:7071/owner/click_product";
const NotificationAll =
    "http://134.209.229.112:7071/owner/get_all_notifications?owner_id=23";
const Historylist = "http://134.209.229.112:7071/owner/History_list/7";
const Vendorslist = "http://134.209.229.112:7071/owner/get_vendor_list/";
const searchVendorListURL = "http://134.209.229.112:7071/owner/search_vendorname?id=";
const UsernametUrl = "http://134.209.229.112:7071/owner/login_title/31";
const GetProfileUrl = "http://134.209.229.112:7071/owner/Get_owner_details?id=23";
const GetInvoiceListUrl = "http://134.209.229.112:7071/owner/get_invoice?id=1&roleid=4";

// const List categoryArray = [decoratorsUrl,bandsUrl,foodUrl];
