import 'package:dio/dio.dart';
import 'package:downloads_path_provider_28/downloads_path_provider_28.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:hexcolor/hexcolor.dart';

import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' hide context;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:service/BottamNavigation/dashboard/dashboard.dart';

import '../../DataApi/constant_apiUrl.dart';
import '../../common/const.dart';
import '../bottom_navigationmodelpage.dart';
import '../bottom_navigationpage.dart';
import 'invoicModelPage.dart';

class PdfViewerPage extends StatefulWidget {
  PdfViewerPage({super.key, this.Id, this.invoiceId});
  final Id;
  final invoiceId;
  @override
  _PdfViewerPageState createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  late File Pfile;
  bool isLoading = false;
  var downloadurl = "";
  Future<void> loadNetwork() async {
    setState(() {
      isLoading = true;
    });
    downloadurl = "${pdfBaseurl}wefix_stagging/generate-invoice/${widget.Id}";
    print("downloadurl: $downloadurl");

    final response = await http.get(Uri.parse(downloadurl));
    final bytes = response.bodyBytes;
    final filename = basename(downloadurl);
    print("downloadurl: $downloadurl\nfilename: $filename");
    final dir = await getApplicationDocumentsDirectory();
    var file = File('${dir.path}/$filename');
    await file.writeAsBytes(bytes, flush: true);
    setState(() {
      Pfile = file;
    });
    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    loadNetwork();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      Future.delayed(Duration(milliseconds: 1));
      final model = Provider.of<invoicModelPage>(context as BuildContext, listen: false);
      await model.InvoicelistingClick(context, widget.Id);
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<invoicModelPage>(builder: (context, model, _) {
      return Scaffold(
          appBar: AppBar(
            title: Text(
              " PDF Viewer",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          body: isLoading
              ? Center(
                  child: CircularProgressIndicator(
                  color: colorTheme,
                ))
              : Center(
                  child: Column(
                    children: [

                      InkWell(
                        onTap: () async {
                          model.showLoader();

                          PermissionStatus mediaPermissionStatus = await Permission.mediaLibrary.status;
                          model.hideLoader();



                          if (mediaPermissionStatus.isGranted) {
                            var dir = await DownloadsPathProvider.downloadsDirectory;
                            if (dir != null) {
                              String savename = "${widget.invoiceId}.pdf";
                              String savePath = dir.path + "/$savename";

                              print(savePath);

                              try {
                                await Dio().download("${pdfBaseurl}wefix_stagging/generate-invoice/${widget.Id}", savePath, onReceiveProgress: (received, total) {
                                  if (total != -1) {
                                    print((received / total * 100).toStringAsFixed(0) + "%");
                                  }
                                });
                                Fluttertoast.showToast(msg: "File is saved to download folder.");
                                Provider.of<BottomnavbarModelPage>(context, listen: false).togglebottomindexreset();
                                Get.off(BottomNavBarPage());
                              } on DioError catch (e) {
                                Fluttertoast.showToast(msg: e.message);
                                print(e.message);
                              }
                            }
                          } else {
                            print("No permission to read and write.");
                            Fluttertoast.showToast(msg:"No permission to read and write.");

                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                          decoration: BoxDecoration(
                            color: HexColor("#6759FF"),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: HexColor("#E5E5E5").withOpacity(1.0)),
                          ),
                          child:Text(
                            "Download",
                            style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: fontWeight600),
                          ),
                        ),
                      ),

                      Expanded(
                        child: PDFView(
                          filePath: Pfile.path,
                        ),
                      )
                    ],
                  ),
                ));
    });
  }
}
